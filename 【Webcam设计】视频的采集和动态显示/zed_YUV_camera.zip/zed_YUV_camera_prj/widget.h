#ifndef WIDGET_H
#define WIDGET_H

#include <QtGui>
#include "videodevice.h"


namespace Ui {
    class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
    Ui::Widget *ui;

    QImage *frame;
    int rs;
    unsigned int len;
    int convert_yuv_to_rgb_buffer();
    void print_quartet(unsigned int i);

    VideoDevice *vd;
    FILE * yuvfile;
    unsigned char rgb_buffer[640*480*3];
    unsigned char * yuv_buffer_pointer;

    char Y_frame[640*480];
    char Cr_frame[240*320];
    char Cb_frame[240*320];

    int write420();

private slots:
    void on_pushButton_start_clicked();
    void paintEvent(QPaintEvent *);

};
#endif // WIDGET_H
